class Carro extends Vehiculo implements Ruta {
    private int velocidadMaxima;
    private String tipoTraccion; // mecánica o automática

    public Carro(String marca, String modelo, String placa, int velocidadMaxima, String tipoTraccion) {
        super(marca, modelo, placa);
        this.velocidadMaxima = velocidadMaxima;
        this.tipoTraccion = tipoTraccion;
    }

    // Implementación de los métodos de la interfaz PruebaRuta
    @Override
    public void acelerar() {
        System.out.println("Acelerando el carro...");
    }

    @Override
    public void frenar() {
        System.out.println("Frenando el carro...");
    }

    @Override
    public void estacionar() {
        System.out.println("Estacionando el carro...");
    }

    @Override
    public void girar() {
        System.out.println("Girando el carro...");
    }

    // Getters y setters para los atributos específicos del carro
    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(int velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    public String getTipoTraccion() {
        return tipoTraccion;
    }

    public void setTipoTraccion(String tipoTraccion) {
        this.tipoTraccion = tipoTraccion;
    }

    // Otros métodos específicos de la clase Carro
}
