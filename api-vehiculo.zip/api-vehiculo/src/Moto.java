class Moto extends Vehiculo implements Ruta {
    private int velocidadMaxima;

    public Moto(String marca, String modelo, String placa, int velocidadMaxima) {
        super(marca, modelo, placa);
        this.velocidadMaxima = velocidadMaxima;
    }

    // Implementación de los métodos de la interfaz PruebaRuta
    @Override
    public void acelerar() {
        System.out.println("Acelerando la moto...");
    }

    @Override
    public void frenar() {
        System.out.println("Frenando la moto...");
    }

    @Override
    public void estacionar() {
        System.out.println("Estacionando la moto...");
    }

    @Override
    public void girar() {
        System.out.println("Girando la moto...");
    }

    // Getters y setters para los atributos específicos de la moto
    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(int velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    // Otros métodos específicos de la clase Moto
}
