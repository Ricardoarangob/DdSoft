interface Ruta {
    void acelerar();
    void frenar();
    void estacionar();
    void girar();
}
